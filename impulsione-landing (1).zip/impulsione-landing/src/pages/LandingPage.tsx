import { useState, useEffect } from "react";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const LOGO_SRC = `${BASE}/logo.png?v=3`;
const DRONE_IMG = `${BASE}/drone-altamira.jpg`;

export default function LandingPage() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  function enviarWhatsApp(e: React.FormEvent) {
    e.preventDefault();
    const form = e.currentTarget as HTMLFormElement;
    const nome = (form.querySelector('input[name="nome"]') as HTMLInputElement)?.value ?? "";
    const empresa = (form.querySelector('input[name="empresa"]') as HTMLInputElement)?.value ?? "";
    const plano = (form.querySelector('select[name="plano"]') as HTMLSelectElement)?.value ?? "";
    const msg = (form.querySelector('textarea[name="mensagem"]') as HTMLTextAreaElement)?.value ?? "";
    let texto = "Olá! Vim pelo site da Impulsione e gostaria de mais informações.%0A%0A";
    if (nome) texto += "*Nome:* " + encodeURIComponent(nome) + "%0A";
    if (empresa) texto += "*Empresa:* " + encodeURIComponent(empresa) + "%0A";
    if (plano) texto += "*Plano:* " + encodeURIComponent(plano) + "%0A";
    if (msg) texto += "*Mensagem:* " + encodeURIComponent(msg);
    window.open("https://wa.me/5593991052714?text=" + texto, "_blank");
  }

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Montserrat:wght@400;600;700;900&display=swap');
        :root {
          --navy: #0a1628;
          --navy-mid: #0d1e38;
          --gold: #c9a227;
          --gold-light: #e0b94a;
          --white: #ffffff;
          --off-white: #f0ead6;
          --text-muted: #8fa0b8;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html { scroll-behavior: smooth; }
        body { font-family: 'Montserrat', sans-serif; background: var(--navy); color: var(--white); overflow-x: hidden; }

        /* NAV */
        .impul-nav {
          position: fixed; top: 0; left: 0; right: 0; z-index: 999;
          display: flex; align-items: center; justify-content: space-between;
          padding: 10px 60px;
          background: rgba(10,22,40,0.97);
          backdrop-filter: blur(10px);
          border-bottom: 1px solid rgba(201,162,39,0.2);
          transition: box-shadow 0.2s;
        }
        .impul-nav.scrolled { box-shadow: 0 4px 20px rgba(0,0,0,0.4); }
        .nav-logo img { height: 44px; width: auto; display: block; object-fit: contain; }
        .nav-links { display: flex; gap: 32px; list-style: none; align-items: center; }
        .nav-links a { color: var(--off-white); text-decoration: none; font-size: 13px; font-weight: 600; letter-spacing: 1px; text-transform: uppercase; transition: color 0.2s; }
        .nav-links a:hover { color: var(--gold); }
        .nav-cta { background: var(--gold); color: var(--navy) !important; padding: 10px 22px; border-radius: 4px; font-weight: 700 !important; }
        .nav-cta:hover { background: var(--gold-light) !important; color: var(--navy) !important; }

        /* HAMBURGER */
        .hamburger {
          display: none; flex-direction: column; gap: 5px; cursor: pointer; background: none; border: none; padding: 4px; z-index: 1000;
        }
        .hamburger span {
          display: block; width: 24px; height: 2px; background: var(--off-white); border-radius: 2px; transition: all 0.3s;
        }
        .hamburger.open span:nth-child(1) { transform: rotate(45deg) translate(5px, 5px); }
        .hamburger.open span:nth-child(2) { opacity: 0; }
        .hamburger.open span:nth-child(3) { transform: rotate(-45deg) translate(5px, -5px); }

        /* MOBILE MENU */
        .mobile-menu {
          display: none; position: fixed; top: 64px; left: 0; right: 0; z-index: 998;
          background: rgba(10,22,40,0.98); backdrop-filter: blur(12px);
          flex-direction: column; align-items: center; gap: 0;
          border-bottom: 1px solid rgba(201,162,39,0.2);
          padding: 20px 0;
          transition: all 0.3s;
        }
        .mobile-menu.open { display: flex; }
        .mobile-menu a {
          color: var(--off-white); text-decoration: none; font-size: 15px; font-weight: 600;
          letter-spacing: 1px; text-transform: uppercase; padding: 14px 40px; width: 100%; text-align: center;
          transition: color 0.2s, background 0.2s;
        }
        .mobile-menu a:hover { color: var(--gold); background: rgba(201,162,39,0.06); }
        .mobile-menu .mobile-cta { background: var(--gold); color: var(--navy) !important; margin: 8px 24px; border-radius: 4px; width: calc(100% - 48px); font-weight: 800 !important; }

        /* HERO */
        #hero { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 120px 60px 80px; position: relative; overflow: hidden; }
        .hero-bg-geo { position: absolute; top: 0; right: 0; bottom: 0; width: 45%; background: var(--navy-mid); clip-path: polygon(15% 0, 100% 0, 100% 100%, 0% 100%); z-index: 0; }
        .hero-geo-accent { position: absolute; top: 0; right: 0; width: 280px; height: 280px; background: var(--gold); clip-path: polygon(100% 0, 0 0, 100% 100%); z-index: 1; opacity: 0.85; }
        .hero-geo-accent2 { position: absolute; top: 100px; right: 100px; width: 180px; height: 180px; background: var(--navy); clip-path: polygon(100% 0, 0 0, 100% 100%); z-index: 2; }
        .hero-content { position: relative; z-index: 10; max-width: 860px; width: 100%; }
        .hero-title-logo { display: block; width: 760px; max-width: 100%; margin: 0 auto 36px auto; object-fit: contain; animation: fadeUp 0.8s ease forwards; }
        .hero-badge { display: inline-block; background: rgba(201,162,39,0.15); border: 1px solid rgba(201,162,39,0.4); color: var(--gold); font-size: 11px; font-weight: 700; letter-spacing: 3px; text-transform: uppercase; padding: 8px 18px; border-radius: 2px; margin-bottom: 20px; }
        .hero-title { font-family: 'Bebas Neue', sans-serif; font-size: clamp(52px, 7vw, 84px); line-height: 0.95; letter-spacing: 2px; margin-bottom: 8px; }
        .hero-title .gold { color: var(--gold); }
        .hero-sub { font-size: 17px; font-weight: 600; color: var(--off-white); margin: 20px 0 14px; border-left: 3px solid var(--gold); padding-left: 16px; }
        .hero-desc { font-size: 15px; color: var(--text-muted); line-height: 1.7; margin-bottom: 40px; max-width: 480px; }
        .hero-btns { display: flex; gap: 16px; flex-wrap: wrap; }
        .btn-primary { background: var(--gold); color: var(--navy); padding: 16px 36px; font-size: 14px; font-weight: 800; letter-spacing: 1.5px; text-transform: uppercase; text-decoration: none; border-radius: 4px; transition: background 0.2s, transform 0.15s; display: inline-block; }
        .btn-primary:hover { background: var(--gold-light); transform: translateY(-2px); }
        .btn-outline { border: 2px solid var(--gold); color: var(--gold); padding: 14px 32px; font-size: 14px; font-weight: 700; letter-spacing: 1.5px; text-transform: uppercase; text-decoration: none; border-radius: 4px; transition: all 0.2s; display: inline-block; }
        .btn-outline:hover { background: rgba(201,162,39,0.1); transform: translateY(-2px); }

        /* SECTIONS */
        .impul-section { padding: 100px 60px; position: relative; }
        .section-label { font-size: 11px; font-weight: 700; letter-spacing: 4px; text-transform: uppercase; color: var(--gold); margin-bottom: 16px; }
        .section-title { font-family: 'Bebas Neue', sans-serif; font-size: clamp(36px, 5vw, 58px); letter-spacing: 2px; line-height: 1; margin-bottom: 20px; }
        .section-title span { color: var(--gold); }
        .section-desc { font-size: 15px; color: var(--text-muted); line-height: 1.7; max-width: 560px; }
        .divider { width: 60px; height: 3px; background: var(--gold); margin: 20px 0; }

        /* WHY */
        #por-que { background: var(--navy-mid); }
        .why-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; margin-top: 56px; }
        .why-card { background: rgba(201,162,39,0.06); border: 1px solid rgba(201,162,39,0.2); border-radius: 8px; padding: 32px 28px; transition: border-color 0.2s, transform 0.2s; }
        .why-card:hover { border-color: rgba(201,162,39,0.5); transform: translateY(-4px); }
        .why-icon { width: 48px; height: 48px; background: rgba(201,162,39,0.15); border-radius: 6px; display: flex; align-items: center; justify-content: center; margin-bottom: 20px; font-size: 22px; }
        .why-card h3 { font-size: 16px; font-weight: 700; color: var(--gold); margin-bottom: 10px; text-transform: uppercase; letter-spacing: 1px; }
        .why-card p { font-size: 14px; color: var(--text-muted); line-height: 1.65; }

        /* SERVICES */
        #servicos { background: var(--navy); }
        .services-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; margin-top: 56px; }
        .service-card { background: var(--navy-mid); border: 1px solid rgba(201,162,39,0.15); border-radius: 8px; padding: 28px 24px; transition: all 0.2s; }
        .service-card:hover { border-color: rgba(201,162,39,0.5); transform: translateY(-4px); }
        .service-icon { font-size: 28px; margin-bottom: 16px; }
        .service-card h3 { font-size: 15px; font-weight: 700; color: var(--white); margin-bottom: 10px; text-transform: uppercase; letter-spacing: 0.5px; }
        .service-card p { font-size: 13px; color: var(--text-muted); line-height: 1.65; }
        .service-price { margin-top: 16px; font-size: 13px; color: var(--gold); font-weight: 700; background: rgba(201,162,39,0.08); padding: 8px 12px; border-radius: 4px; display: inline-block; }

        /* PLANS */
        #planos { background: var(--navy-mid); overflow: hidden; }
        .plans-intro { display: flex; gap: 80px; align-items: flex-start; margin-bottom: 64px; }
        .plans-intro-text { flex: 1; }
        .plans-intro-note { flex: 0 0 280px; background: rgba(201,162,39,0.08); border-left: 3px solid var(--gold); padding: 24px; border-radius: 0 8px 8px 0; font-size: 14px; color: var(--off-white); line-height: 1.7; }
        .plans-intro-note a { color: var(--gold); font-weight: 700; text-decoration: none; }
        .plans-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; }
        .plan-card { background: rgba(10,22,40,0.8); border: 1px solid rgba(201,162,39,0.2); border-radius: 10px; padding: 32px 24px; position: relative; transition: transform 0.2s, border-color 0.2s; display: flex; flex-direction: column; }
        .plan-card:hover { transform: translateY(-6px); border-color: rgba(201,162,39,0.5); }
        .plan-card.featured { background: rgba(201,162,39,0.1); border: 2px solid var(--gold); }
        .plan-badge { position: absolute; top: -13px; left: 50%; transform: translateX(-50%); background: var(--gold); color: var(--navy); font-size: 10px; font-weight: 800; letter-spacing: 2px; text-transform: uppercase; padding: 5px 16px; border-radius: 20px; white-space: nowrap; }
        .plan-name { font-family: 'Bebas Neue', sans-serif; font-size: 26px; letter-spacing: 2px; color: var(--gold); margin-bottom: 6px; }
        .plan-price { font-size: 32px; font-weight: 900; color: var(--white); margin-bottom: 4px; }
        .plan-price span { font-size: 16px; font-weight: 600; color: var(--text-muted); }
        .plan-divider { width: 40px; height: 2px; background: var(--gold); margin: 20px 0; }
        .plan-features { list-style: none; margin-bottom: 28px; flex: 1; }
        .plan-features li { font-size: 13px; color: var(--off-white); padding: 7px 0; border-bottom: 1px solid rgba(255,255,255,0.06); display: flex; align-items: flex-start; gap: 10px; line-height: 1.5; }
        .plan-features li::before { content: ''; width: 7px; height: 7px; background: var(--gold); border-radius: 50%; flex-shrink: 0; margin-top: 5px; }
        .plan-cta { display: block; text-align: center; background: var(--gold); color: var(--navy); padding: 13px; border-radius: 6px; font-size: 13px; font-weight: 800; letter-spacing: 1.5px; text-transform: uppercase; text-decoration: none; transition: background 0.2s; }
        .plan-cta:hover { background: var(--gold-light); }
        .plan-cta.outline { background: transparent; border: 2px solid var(--gold); color: var(--gold); }
        .plan-cta.outline:hover { background: rgba(201,162,39,0.1); }

        /* CTA BANNER */
        #cta-banner { background: var(--gold); padding: 80px 60px; text-align: center; position: relative; overflow: hidden; }
        #cta-banner::before { content: ''; position: absolute; top: 0; left: 0; width: 0; height: 0; border-right: 200px solid transparent; border-top: 200px solid rgba(0,0,0,0.08); }
        #cta-banner::after { content: ''; position: absolute; bottom: 0; right: 0; width: 0; height: 0; border-left: 200px solid transparent; border-bottom: 200px solid rgba(0,0,0,0.08); }
        .cta-banner-title { font-family: 'Bebas Neue', sans-serif; font-size: clamp(40px, 6vw, 72px); color: var(--navy); letter-spacing: 2px; line-height: 1; margin-bottom: 16px; position: relative; z-index: 2; }
        .cta-banner-sub { font-size: 16px; color: rgba(10,22,40,0.75); margin-bottom: 36px; position: relative; z-index: 2; }
        .btn-navy { background: var(--navy); color: var(--gold); padding: 16px 40px; font-size: 14px; font-weight: 800; letter-spacing: 1.5px; text-transform: uppercase; text-decoration: none; border-radius: 4px; transition: all 0.2s; display: inline-block; position: relative; z-index: 2; }
        .btn-navy:hover { background: var(--navy-mid); transform: translateY(-2px); }

        /* CONTACT */
        #contato { background: var(--navy); }
        .contact-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 60px; margin-top: 56px; align-items: start; }
        .contact-item { display: flex; align-items: center; gap: 20px; padding: 24px; background: rgba(201,162,39,0.06); border: 1px solid rgba(201,162,39,0.18); border-radius: 8px; margin-bottom: 16px; text-decoration: none; transition: all 0.2s; color: var(--white); }
        .contact-item:hover { border-color: var(--gold); background: rgba(201,162,39,0.12); transform: translateX(6px); }
        .contact-icon { width: 48px; height: 48px; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
        .contact-icon.wpp { background: #25D366; }
        .contact-icon.ig { background: radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, #fd5949 45%, #d6249f 60%, #285AEB 90%); }
        .contact-icon.gmail { background: #ffffff; }
        .contact-icon svg { width: 26px; height: 26px; display: block; }
        .contact-label { font-size: 11px; font-weight: 700; letter-spacing: 2px; text-transform: uppercase; color: var(--gold); margin-bottom: 4px; }
        .contact-value { font-size: 15px; font-weight: 600; color: var(--white); }
        .contact-form-title { font-family: 'Bebas Neue', sans-serif; font-size: 32px; letter-spacing: 2px; color: var(--gold); margin-bottom: 20px; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 11px; font-weight: 700; letter-spacing: 2px; text-transform: uppercase; color: var(--text-muted); margin-bottom: 8px; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; background: rgba(255,255,255,0.04); border: 1px solid rgba(201,162,39,0.25); border-radius: 6px; padding: 13px 16px; color: var(--white); font-family: 'Montserrat', sans-serif; font-size: 14px; outline: none; transition: border-color 0.2s; }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color: var(--gold); }
        .form-group select option { background: var(--navy-mid); color: var(--white); }
        .form-group textarea { resize: vertical; min-height: 100px; }
        .form-submit { width: 100%; background: var(--gold); color: var(--navy); border: none; padding: 16px; font-family: 'Montserrat', sans-serif; font-size: 14px; font-weight: 800; letter-spacing: 2px; text-transform: uppercase; border-radius: 6px; cursor: pointer; transition: all 0.2s; }
        .form-submit:hover { background: var(--gold-light); transform: translateY(-2px); }

        /* DRONE HERO SECTION */
        #drone-diferencial {
          position: relative; overflow: hidden;
          background: var(--navy);
          padding: 0;
        }
        .drone-img-wrapper {
          position: relative; width: 100%; height: 600px; overflow: hidden;
        }
        .drone-img-wrapper img {
          width: 100%; height: 100%; object-fit: cover; object-position: center 30%;
          display: block;
          filter: brightness(0.52) saturate(1.1);
          transition: transform 8s ease;
        }
        .drone-img-wrapper:hover img { transform: scale(1.04); }
        .drone-img-overlay {
          position: absolute; inset: 0;
          background: linear-gradient(to right, rgba(10,22,40,0.92) 38%, rgba(10,22,40,0.2) 100%),
                      linear-gradient(to top, rgba(10,22,40,0.7) 0%, transparent 50%);
          display: flex; align-items: center;
          padding: 60px;
        }
        .drone-text-block { max-width: 560px; }
        .drone-eyebrow {
          display: inline-flex; align-items: center; gap: 10px;
          background: rgba(201,162,39,0.15); border: 1px solid rgba(201,162,39,0.45);
          color: var(--gold); font-size: 10px; font-weight: 800; letter-spacing: 3.5px;
          text-transform: uppercase; padding: 8px 16px; border-radius: 2px; margin-bottom: 22px;
        }
        .drone-eyebrow svg { width: 14px; height: 14px; fill: var(--gold); flex-shrink: 0; }
        .drone-headline {
          font-family: 'Bebas Neue', sans-serif;
          font-size: clamp(44px, 6vw, 72px);
          line-height: 0.95; letter-spacing: 2px;
          margin-bottom: 18px; color: var(--white);
        }
        .drone-headline .gold { color: var(--gold); }
        .drone-desc {
          font-size: 15px; color: var(--off-white); line-height: 1.75;
          margin-bottom: 32px; max-width: 460px;
          border-left: 3px solid var(--gold); padding-left: 16px;
        }
        .drone-caption {
          position: absolute; bottom: 18px; right: 24px;
          font-size: 10px; color: rgba(255,255,255,0.4);
          letter-spacing: 1.5px; text-transform: uppercase;
          display: flex; align-items: center; gap: 6px;
        }
        .drone-caption::before {
          content: ''; display: block; width: 20px; height: 1px; background: rgba(255,255,255,0.3);
        }

        /* DRONE SERVICES GRID */
        #drone-servicos { background: #07111f; padding: 80px 60px; }
        .drone-services-header { display: flex; align-items: flex-end; justify-content: space-between; margin-bottom: 48px; gap: 32px; flex-wrap: wrap; }
        .drone-services-title { font-family: 'Bebas Neue', sans-serif; font-size: clamp(34px, 4.5vw, 52px); letter-spacing: 2px; line-height: 1; }
        .drone-services-title span { color: var(--gold); }
        .drone-services-sub { font-size: 14px; color: var(--text-muted); max-width: 300px; line-height: 1.65; text-align: right; }
        .drone-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
        .drone-card {
          position: relative; overflow: hidden;
          background: linear-gradient(135deg, rgba(201,162,39,0.08) 0%, rgba(13,30,56,0.95) 100%);
          border: 1px solid rgba(201,162,39,0.22); border-radius: 10px;
          padding: 32px 28px; transition: all 0.3s; cursor: default;
        }
        .drone-card::before {
          content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px;
          background: linear-gradient(to right, var(--gold), transparent);
          opacity: 0; transition: opacity 0.3s;
        }
        .drone-card:hover { transform: translateY(-6px); border-color: rgba(201,162,39,0.55); box-shadow: 0 16px 40px rgba(0,0,0,0.4); }
        .drone-card:hover::before { opacity: 1; }
        .drone-card-icon { font-size: 32px; margin-bottom: 18px; display: block; }
        .drone-card-tag {
          display: inline-block; font-size: 9px; font-weight: 800; letter-spacing: 2.5px;
          text-transform: uppercase; color: var(--gold);
          background: rgba(201,162,39,0.1); border: 1px solid rgba(201,162,39,0.25);
          padding: 4px 10px; border-radius: 2px; margin-bottom: 14px;
        }
        .drone-card h3 { font-size: 15px; font-weight: 700; color: var(--white); margin-bottom: 10px; text-transform: uppercase; letter-spacing: 0.5px; }
        .drone-card p { font-size: 13px; color: var(--text-muted); line-height: 1.7; margin-bottom: 18px; }
        .drone-card-price {
          font-size: 13px; font-weight: 800; color: var(--gold);
          background: rgba(201,162,39,0.1); border: 1px solid rgba(201,162,39,0.2);
          padding: 8px 14px; border-radius: 4px; display: inline-block;
        }
        .drone-card-cta {
          display: inline-block; margin-top: 18px; font-size: 12px; font-weight: 700;
          color: var(--gold); text-decoration: none; letter-spacing: 1px;
          text-transform: uppercase; border-bottom: 1px solid rgba(201,162,39,0.35);
          padding-bottom: 2px; transition: all 0.2s;
        }
        .drone-card-cta:hover { color: var(--gold-light); border-color: var(--gold-light); }
        .drone-card.highlight {
          background: linear-gradient(135deg, rgba(201,162,39,0.14) 0%, rgba(13,30,56,0.98) 100%);
          border: 1.5px solid rgba(201,162,39,0.45);
        }
        .drone-stats-bar {
          display: flex; gap: 0; margin-top: 56px;
          border: 1px solid rgba(201,162,39,0.18); border-radius: 10px; overflow: hidden;
        }
        .drone-stat {
          flex: 1; padding: 28px 24px; text-align: center;
          border-right: 1px solid rgba(201,162,39,0.12);
          background: rgba(201,162,39,0.04);
        }
        .drone-stat:last-child { border-right: none; }
        .drone-stat-num {
          font-family: 'Bebas Neue', sans-serif; font-size: 40px; color: var(--gold);
          letter-spacing: 2px; line-height: 1; display: block;
        }
        .drone-stat-label { font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1.5px; margin-top: 6px; display: block; }

        /* FOOTER */
        .impul-footer { background: #060d1a; padding: 40px 60px; display: flex; flex-direction: column; align-items: center; justify-content: center; border-top: 1px solid rgba(201,162,39,0.15); gap: 12px; text-align: center; }
        .footer-logo-wrap img { height: 52px; width: auto; display: block; object-fit: contain; }
        .footer-copy { font-size: 12px; color: var(--text-muted); }

        /* ANIMATIONS */
        @keyframes fadeUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        .fade-up { animation: fadeUp 0.7s ease forwards; }
        .delay-1 { animation-delay: 0.1s; opacity: 0; }
        .delay-2 { animation-delay: 0.25s; opacity: 0; }
        .delay-3 { animation-delay: 0.4s; opacity: 0; }
        .delay-4 { animation-delay: 0.55s; opacity: 0; }

        /* RESPONSIVE — large tablets */
        @media (max-width: 1100px) {
          .plans-grid { grid-template-columns: repeat(2, 1fr); }
          .services-grid { grid-template-columns: repeat(2, 1fr); }
        }

        /* RESPONSIVE — mobile */
        @media (max-width: 860px) {
          .impul-nav { padding: 12px 20px; }
          .nav-links { display: none; }
          .hamburger { display: flex; }

          #hero { padding: 100px 20px 60px; }
          .hero-bg-geo { display: none; }
          .hero-geo-accent { width: 160px; height: 160px; }
          .hero-geo-accent2 { width: 100px; height: 100px; top: 60px; right: 60px; }
          .hero-title-logo { width: 90%; }
          .hero-title { font-size: clamp(44px, 10vw, 64px); }
          .hero-sub { font-size: 15px; }
          .hero-desc { font-size: 14px; }

          .impul-section { padding: 60px 20px; }
          .why-grid { grid-template-columns: 1fr; }
          .services-grid { grid-template-columns: 1fr; }
          .plans-grid { grid-template-columns: 1fr; }
          .plans-intro { flex-direction: column; gap: 24px; }
          .plans-intro-note { flex: unset; width: 100%; }
          .contact-grid { grid-template-columns: 1fr; gap: 36px; }
          #cta-banner { padding: 60px 20px; }
          .impul-footer { padding: 32px 20px; }
          .drone-img-wrapper { height: 480px; }
          .drone-img-overlay { padding: 32px 24px; align-items: flex-end; }
          .drone-text-block { max-width: 100%; }
          .drone-headline { font-size: clamp(38px, 9vw, 56px); }
          #drone-servicos { padding: 60px 20px; }
          .drone-grid { grid-template-columns: 1fr; }
          .drone-services-sub { text-align: left; max-width: 100%; }
          .drone-stats-bar { flex-wrap: wrap; }
          .drone-stat { flex: 1 1 45%; border-bottom: 1px solid rgba(201,162,39,0.12); }
        }

        @media (max-width: 480px) {
          .hero-btns { flex-direction: column; }
          .btn-primary, .btn-outline { width: 100%; text-align: center; }
          .plans-intro-note { font-size: 13px; }
        }
      `}</style>

      {/* NAV */}
      <nav className={`impul-nav${scrolled ? " scrolled" : ""}`}>
        <div className="nav-logo">
          <img src={LOGO_SRC} alt="Impulsione Marketing" />
        </div>
        <ul className="nav-links">
          <li><a href="#por-que">Por que nós</a></li>
          <li><a href="#drone-diferencial">Drone</a></li>
          <li><a href="#servicos">Serviços</a></li>
          <li><a href="#planos">Planos</a></li>
          <li><a href="#contato" className="nav-cta">Falar agora</a></li>
        </ul>
        <button
          className={`hamburger${menuOpen ? " open" : ""}`}
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Menu"
        >
          <span></span>
          <span></span>
          <span></span>
        </button>
      </nav>

      {/* MOBILE MENU */}
      <div className={`mobile-menu${menuOpen ? " open" : ""}`}>
        <a href="#por-que" onClick={() => setMenuOpen(false)}>Por que nós</a>
        <a href="#drone-diferencial" onClick={() => setMenuOpen(false)}>Drone</a>
        <a href="#servicos" onClick={() => setMenuOpen(false)}>Serviços</a>
        <a href="#planos" onClick={() => setMenuOpen(false)}>Planos</a>
        <a href="#contato" className="mobile-cta" onClick={() => setMenuOpen(false)}>Falar agora</a>
      </div>

      {/* HERO */}
      <section id="hero">
        <div className="hero-bg-geo"></div>
        <div className="hero-geo-accent"></div>
        <div className="hero-geo-accent2"></div>
        <div className="hero-content">
          <img src={LOGO_SRC} alt="Impulsione Marketing" className="hero-title-logo" />
          <div className="hero-badge fade-up delay-1">Agência de Marketing Digital</div>
          <h1 className="hero-title fade-up delay-2">
            Transformamos<br />suas ideias em<br /><span className="gold">resultados.</span>
          </h1>
          <p className="hero-sub fade-up delay-3">Conheça nossa proposta personalizada para impulsionar seu sucesso.</p>
          <p className="hero-desc fade-up delay-3">Somos especialistas em gestão de redes sociais, produção de conteúdo com drone, tráfego pago e estratégia digital. Levamos sua marca a outro nível.</p>
          <div className="hero-btns fade-up delay-4">
            <a href="#planos" className="btn-primary">Ver planos</a>
            <a href="#contato" className="btn-outline">Falar com a equipe</a>
          </div>
        </div>
      </section>

      {/* POR QUE */}
      <section id="por-que" className="impul-section">
        <div className="section-label">Diferenciais</div>
        <h2 className="section-title">Por que contratar uma<br /><span>Agência de Marketing?</span></h2>
        <div className="divider"></div>
        <p className="section-desc">Terceirizar o marketing com quem entende do assunto é a decisão mais inteligente para crescer com consistência.</p>
        <div className="why-grid">
          <div className="why-card">
            <div className="why-icon">🏆</div>
            <h3>Expertise Profissional</h3>
            <p>Equipe qualificada e atualizada com as últimas tendências do mercado digital. Você tem acesso ao melhor, sem precisar contratar internamente.</p>
          </div>
          <div className="why-card">
            <div className="why-icon">⏱️</div>
            <h3>Economia de Tempo</h3>
            <p>Você foca no seu negócio enquanto cuidamos de todo o marketing. Planejamento, criação, publicação e gestão — tudo em nossas mãos.</p>
          </div>
          <div className="why-card">
            <div className="why-icon">🎯</div>
            <h3>Estratégias Personalizadas</h3>
            <p>Soluções sob medida para o seu público e mercado. Nada de fórmula pronta: cada cliente tem uma estratégia única e pensada para ele.</p>
          </div>
        </div>
      </section>

      {/* DRONE DIFERENCIAL — HERO IMAGE */}
      <section id="drone-diferencial">
        <div className="drone-img-wrapper">
          <img src={DRONE_IMG} alt="Vista aérea de Altamira com drone DJI Mini 4 Pro" />
          <div className="drone-img-overlay">
            <div className="drone-text-block">
              <div className="drone-eyebrow">
                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z"/></svg>
                Diferencial exclusivo — DJI Mini 4 Pro
              </div>
              <h2 className="drone-headline">
                Sua marca<br />vista de<br /><span className="gold">outro ângulo.</span>
              </h2>
              <p className="drone-desc">
                Enquanto a concorrência usa fotos comuns, seus clientes verão a cidade aos seus pés. Imagens e vídeos aéreos profissionais que criam impacto imediato, transmitem autoridade e ficam na memória.
              </p>
              <a href="#drone-servicos" className="btn-primary">Ver serviços com drone →</a>
            </div>
          </div>
          <div className="drone-caption">Santarém, Pará — captado com DJI Mini 4 Pro</div>
        </div>
      </section>

      {/* DRONE SERVIÇOS */}
      <section id="drone-servicos" className="impul-section" style={{background: '#07111f', padding: '80px 60px'}}>
        <div className="drone-services-header">
          <div>
            <div className="section-label">Captura Aérea Profissional</div>
            <div className="drone-services-title">Serviços com<br /><span>Drone</span></div>
            <div className="divider"></div>
          </div>
          <div className="drone-services-sub">
            O drone não é só um equipamento — é um argumento visual que separa marcas comuns das que se destacam.
          </div>
        </div>
        <div className="drone-grid">
          <div className="drone-card">
            <span className="drone-card-icon">📸</span>
            <div className="drone-card-tag">Imagem Estática</div>
            <h3>Fotografia Aérea</h3>
            <p>Fotos aéreas em alta resolução para imobiliárias, construtoras, fazendas, eventos e empresas. Mostre a dimensão real do seu espaço.</p>
            <div className="drone-card-price">R$ 150 por sessão</div><br />
            <a href="#contato" className="drone-card-cta">Solicitar sessão →</a>
          </div>
          <div className="drone-card highlight">
            <span className="drone-card-icon">🎬</span>
            <div className="drone-card-tag">Vídeo Completo</div>
            <h3>Vídeo Aéreo + Edição</h3>
            <p>Captação aérea com roteiro, trilha sonora, legendas e edição profissional. Entregue pronto para Instagram, YouTube e apresentações.</p>
            <div className="drone-card-price">A partir de R$ 350/mês</div><br />
            <a href="#contato" className="drone-card-cta">Solicitar vídeo →</a>
          </div>
          <div className="drone-card">
            <span className="drone-card-icon">🏢</span>
            <div className="drone-card-tag">Segmentos ideais</div>
            <h3>Para quem é ideal?</h3>
            <p>Imobiliárias, construtoras, eventos, comércio local, agronegócio, turismo, igrejas, escolas e qualquer negócio que queira impressionar.</p>
            <div style={{marginTop: '16px', display: 'flex', flexDirection: 'column', gap: '8px'}}>
              {['🏡 Imobiliárias e loteamentos','📅 Eventos e formaturas','🌱 Agronegócio e fazendas','🏪 Fachadas e inaugurações'].map(item => (
                <div key={item} style={{fontSize: '12px', color: 'var(--off-white)', display: 'flex', alignItems: 'center', gap: '8px'}}>
                  <span style={{color: 'var(--gold)', fontSize: '10px'}}>▸</span> {item}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Stats bar */}
        <div className="drone-stats-bar">
          <div className="drone-stat">
            <span className="drone-stat-num">4K</span>
            <span className="drone-stat-label">Resolução de vídeo</span>
          </div>
          <div className="drone-stat">
            <span className="drone-stat-num">48MP</span>
            <span className="drone-stat-label">Câmera DJI Mini 4 Pro</span>
          </div>
          <div className="drone-stat">
            <span className="drone-stat-num">10×</span>
            <span className="drone-stat-label">Mais engajamento médio</span>
          </div>
          <div className="drone-stat">
            <span className="drone-stat-num">24h</span>
            <span className="drone-stat-label">Prazo de entrega</span>
          </div>
        </div>
      </section>

      {/* SERVIÇOS */}
      <section id="servicos" className="impul-section">
        <div className="section-label">O que oferecemos</div>
        <h2 className="section-title">Outros <span>Serviços</span></h2>
        <div className="divider"></div>
        <p className="section-desc">Além do drone, oferecemos serviços avulsos para complementar sua estratégia digital.</p>
        <div className="services-grid">
          <div className="service-card">
            <div className="service-icon">📱</div>
            <h3>Posts &amp; Vídeos para Redes</h3>
            <p>4 posts + 2 vídeos editados com identidade visual profissional e roteiro estratégico para engajar seu público.</p>
            <div className="service-price">A partir de R$ 700/mês</div>
          </div>
          <div className="service-card">
            <div className="service-icon">🎬</div>
            <h3>Vídeo Maker Mobile</h3>
            <p>Vídeos gravados via celular com roteiro e edição completa, entrega pronta para publicar nas suas redes sociais.</p>
            <div className="service-price">A partir de R$ 200/mês</div>
          </div>
          <div className="service-card">
            <div className="service-icon">🎯</div>
            <h3>Tráfego Pago</h3>
            <p>Criação e gerenciamento de campanhas pagas no Instagram e Facebook Ads para gerar leads e vendas.</p>
            <div className="service-price">R$ 350 + verba de anúncios</div>
          </div>
        </div>
      </section>

      {/* PLANOS */}
      <section id="planos" className="impul-section">
        <div className="plans-intro">
          <div className="plans-intro-text">
            <div className="section-label">Planos mensais</div>
            <h2 className="section-title">Escolha o<br /><span>seu plano</span></h2>
            <div className="divider"></div>
            <p className="section-desc">Planos completos e escaláveis para negócios de todos os tamanhos. Escolha o que melhor se encaixa no seu momento.</p>
          </div>
          <div className="plans-intro-note">
            💡 <strong>Não tem certeza qual plano escolher?</strong><br /><br />
            Fale com nossa equipe e receba uma indicação personalizada para o seu tipo de negócio e objetivos.<br /><br />
            <a href="#contato">→ Falar com consultor</a>
          </div>
        </div>
        <div className="plans-grid">
          <div className="plan-card">
            <div className="plan-name">Essencial</div>
            <div className="plan-price">R$ 750<span>/mês</span></div>
            <div className="plan-divider"></div>
            <ul className="plan-features">
              <li>Calendário mensal simples</li>
              <li>Até 6 posts mensais</li>
              <li>4 vídeos já editados</li>
              <li>Sem gerenciamento de redes</li>
            </ul>
            <a href="#contato" className="plan-cta outline">Contratar</a>
          </div>
          <div className="plan-card">
            <div className="plan-name">Padrão</div>
            <div className="plan-price">R$ 1.000<span>/mês</span></div>
            <div className="plan-divider"></div>
            <ul className="plan-features">
              <li>Planejamento estratégico</li>
              <li>Gerenciamento de redes</li>
              <li>8 posts mensais (feed e story)</li>
              <li>6 vídeos editados</li>
              <li>Imagens com drone (+R$180)</li>
              <li>Sem tráfego pago</li>
            </ul>
            <a href="#contato" className="plan-cta outline">Contratar</a>
          </div>
          <div className="plan-card">
            <div className="plan-name">Premium</div>
            <div className="plan-price">R$ 1.800<span>/mês</span></div>
            <div className="plan-divider"></div>
            <ul className="plan-features">
              <li>Estratégia avançada de conteúdo</li>
              <li>Até 10 artes/posts mensais</li>
              <li>8 vídeos editados + roteiros</li>
              <li>Captação com drone inclusa</li>
              <li>Gestão de redes</li>
              <li>Relatórios detalhados</li>
              <li>Tráfego pago incluso</li>
            </ul>
            <a href="#contato" className="plan-cta outline">Contratar</a>
          </div>
          <div className="plan-card featured">
            <div className="plan-badge">Mais completo</div>
            <div className="plan-name">Impulsione</div>
            <div className="plan-price">R$ 2.900<span>/mês</span></div>
            <div className="plan-divider"></div>
            <ul className="plan-features">
              <li>Estratégia avançada de conteúdo</li>
              <li>Até 18 posts mensais + stories</li>
              <li>16 vídeos editados + roteiros</li>
              <li>Captação com drone inclusa</li>
              <li>Gestão completa de redes</li>
              <li>Resposta rápida direct e comentários</li>
              <li>Tráfego pago + gestão de campanha</li>
              <li>Reuniões mensais e treinamentos</li>
            </ul>
            <a href="#contato" className="plan-cta">Contratar agora</a>
          </div>
        </div>
      </section>

      {/* CTA BANNER */}
      <div id="cta-banner">
        <h2 className="cta-banner-title">Pronto para elevar<br />sua presença online?</h2>
        <p className="cta-banner-sub">Entre em contato e vamos criar juntos o plano perfeito para o seu sucesso.</p>
        <a href="#contato" className="btn-navy">Falar com a equipe agora</a>
      </div>

      {/* CONTATO */}
      <section id="contato" className="impul-section">
        <div className="section-label">Contato</div>
        <h2 className="section-title">Entre em<br /><span>contato agora!</span></h2>
        <div className="divider"></div>
        <div className="contact-grid">
          <div>
            {/* WhatsApp */}
            <a href="https://wa.me/5593991052714" className="contact-item" target="_blank" rel="noopener noreferrer">
              <div className="contact-icon wpp">
                <svg viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
              </div>
              <div>
                <div className="contact-label">WhatsApp</div>
                <div className="contact-value">(93) 99105-2714</div>
              </div>
            </a>

            {/* Instagram */}
            <a href="https://instagram.com/impulsionemktstm" className="contact-item" target="_blank" rel="noopener noreferrer">
              <div className="contact-icon ig">
                <svg viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
                </svg>
              </div>
              <div>
                <div className="contact-label">Instagram</div>
                <div className="contact-value">@impulsionemktstm</div>
              </div>
            </a>

            {/* Gmail — Google Gmail official icon (M envelope multi-color) */}
            <a href="mailto:impulsionemarketingstm@gmail.com" className="contact-item">
              <div className="contact-icon gmail">
                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="26" height="26">
                  {/* White envelope background */}
                  <path d="M2 6.5C2 5.12 3.12 4 4.5 4h15C20.88 4 22 5.12 22 6.5v11c0 1.38-1.12 2.5-2.5 2.5h-15C3.12 20 2 18.88 2 17.5v-11z" fill="#fff"/>
                  {/* Red left outer flap */}
                  <path d="M2 6.5L12 13l10-6.5" stroke="none" fill="none"/>
                  {/* Red border */}
                  <path d="M4.5 4C3.12 4 2 5.12 2 6.5L12 13 22 6.5C22 5.12 20.88 4 19.5 4h-15z" fill="#EA4335"/>
                  {/* Green left side */}
                  <path d="M2 6.5v11C2 18.88 3.12 20 4.5 20H9V10.5L2 6.5z" fill="#34A853"/>
                  {/* Yellow right side */}
                  <path d="M22 6.5v11C22 18.88 20.88 20 19.5 20H15V10.5l7-4z" fill="#FBBC05"/>
                  {/* Blue center bottom */}
                  <path d="M9 10.5V20h6V10.5L12 13l-3-2.5z" fill="#4285F4"/>
                </svg>
              </div>
              <div>
                <div className="contact-label">Gmail</div>
                <div className="contact-value">impulsionemarketingstm@gmail.com</div>
              </div>
            </a>
          </div>

          <div>
            <div className="contact-form-title">Solicite uma proposta</div>
            <form onSubmit={enviarWhatsApp}>
              <div className="form-group">
                <label htmlFor="nome">Seu nome</label>
                <input id="nome" name="nome" type="text" placeholder="Nome completo" />
              </div>
              <div className="form-group">
                <label htmlFor="whatsapp">WhatsApp</label>
                <input id="whatsapp" name="whatsapp" type="tel" placeholder="(00) 00000-0000" />
              </div>
              <div className="form-group">
                <label htmlFor="empresa">Empresa / Marca</label>
                <input id="empresa" name="empresa" type="text" placeholder="Nome da sua empresa" />
              </div>
              <div className="form-group">
                <label htmlFor="plano">Plano de interesse</label>
                <select id="plano" name="plano">
                  <option value="">Selecione um plano...</option>
                  <option>Plano Essencial – R$ 750/mês</option>
                  <option>Plano Padrão – R$ 1.000/mês</option>
                  <option>Plano Premium – R$ 1.800/mês</option>
                  <option>Plano Impulsione – R$ 2.900/mês</option>
                  <option>Serviço avulso</option>
                  <option>Não sei ainda</option>
                </select>
              </div>
              <div className="form-group">
                <label htmlFor="mensagem">Mensagem (opcional)</label>
                <textarea id="mensagem" name="mensagem" placeholder="Conte um pouco sobre o seu negócio..."></textarea>
              </div>
              <button type="submit" className="form-submit">Enviar pelo WhatsApp →</button>
            </form>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="impul-footer">
        <div className="footer-logo-wrap">
          <img src={LOGO_SRC} alt="Impulsione Marketing" />
        </div>
        <div className="footer-copy">© 2025 Impulsione Marketing. Todos os direitos reservados.</div>
      </footer>
    </>
  );
}
